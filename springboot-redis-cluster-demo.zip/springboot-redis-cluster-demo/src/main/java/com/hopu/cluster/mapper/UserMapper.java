package com.hopu.cluster.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hopu.cluster.pojo.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMapper extends BaseMapper<User> {
}

package com.hopu.cluster.service;

import com.hopu.cluster.mapper.UserMapper;
import com.hopu.cluster.pojo.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


public interface UserService {

    List<User> selectList();
}

package com.hopu.cluster;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.hopu.cluster.mapper")
public class SpringbootRedisClusterDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootRedisClusterDemoApplication.class, args);
    }

}

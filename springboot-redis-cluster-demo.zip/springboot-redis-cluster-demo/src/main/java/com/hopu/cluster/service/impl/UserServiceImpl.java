package com.hopu.cluster.service.impl;

import com.hopu.cluster.mapper.UserMapper;
import com.hopu.cluster.pojo.User;
import com.hopu.cluster.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public List<User> selectList() {
        /*
            1. 先查redis中有没有用户列表的数据，如果有就直接显示redis中的数据
            2. 如果没有就查MySQL 中的用户数据，然后写入到redis中，并返回给控制器
                （实际生产：会做缓存预热，【预先查MySQL中的数据，存到redis中】）
         */

        List<User> users =  redisTemplate.opsForList().range(("users_key"),0,-1);
        System.out.println("从redis中查到的users: "+users);
        if(users.size()==0){
            users = userMapper.selectList(null);
            System.out.println("从mysql中查到的users: "+users);
            redisTemplate.opsForList().leftPushAll("users_key",users);
        }
        return users;
    }
}
